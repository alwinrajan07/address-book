
/*
Name:Alwin Rajan
Admission id:25021_221
Project Name : Address Book Application
Description  :  
                --> The Address Book Application is a C-based console project designed to efficiently manage personal or
                     professional contact information.
                --> It provides a user-friendly interface and robust features to create, organize, and maintain a contact list with ease.
Key Features : 
            1: Create New Contact 
            2: Search the Contact
            3: Edit the given Contact
            4: Delete the existing Contact
            5: List all the given Contact By 
                --> By Sorting the Name
                --> By Sorting the Phone number
                --> By Sorting the Email id
                --> No Sorting 
            6: Save the New Contact to file
                --> Automatically Save the conatct to "csv file" for future use.
            7. Load Contacts to file
                --> Automatically Load existing contacts to "csv file".

Key Features : 
            --> Input Validation : Ensures that all entered names, phone numbers, and email addresses follow proper formats.
            --> Duplicate prevention : Ensures the created Phone number or email id Already present or not.(Data Integration)
            --> User-Friendly Interface : Simple menu-driven design for easy navigation and operation.

Sample Input and Output :
 
 Address Book Menu:
 1. Create contact
 2. Search contact
 3. Edit conatct
 4. Delete contact
 5. List the contact
 6. Save contact
 7. Exit
 --> Enter the choice :

 case : 1
 --> Enter the choice : 1
 1. Enter the Name         : alwinr
 2. Enter the phone number : 1112223333
 3. Enter the email        : alwin@gmail.com

      --------> Contact created successfully <----------
 case : 2
 --> Enter the choice : 2
        -------> Search the contact <-------
 1. By Name
 2. By phone number
 3. By Email id

 --> Enter the choice to Edit : 1
--> Enter the Name : alwin12
  -- > Invalid input < --



*/

#include <stdio.h>
#include<string.h>
#include "contact.h"

int main() {
    int choice;
    AddressBook addressBook;
    initialize(&addressBook); // Initialize the address book

    do {
        printf("\nAddress Book Menu:\n");//ask the user to enter options
        printf("1. Create contact\n");//if enter 1 create option will enable
        printf("2. Search contact\n");//if 2 search contacts
        printf("3. Edit contact\n");
        printf("4. Delete contact\n");
        printf("5. List all contacts\n");
    	printf("6. Save contacts\n");		
        printf("7. Exit\n");
        printf("Enter your choice: ");
        scanf("%d", &choice);
        int sortChoice=2;
        switch (choice) {
            case 1:
                createContact(&addressBook);
                break;
            case 2:
                searchContact(&addressBook);
                break;
            case 3:
                editContact(&addressBook);
                break;
            case 4:
                deleteContact(&addressBook);
                break;
            case 5:          
                listContacts(&addressBook,sortChoice);
                break;
            case 6:
                printf("Saving and Exiting...\n");
                saveContactsToFile(&addressBook);
                break;
            default:
                printf("Invalid choice. Please try again.\n");
        }
    } while (choice != 7);
    
       return 0;
}
