#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "contact.h"
#include "file.h"

void listContacts(AddressBook *addressBook,int sort) 
{
    int num;
    printf("\n");
   printf("How to sort:\n");
   printf("1.Sort By name:\n");
   printf("2.Sort By Email\n");
   printf("3.No sorting:");
   scanf(" %d",&num);//read num;
    if(num==1)//if num equals to 1 sort by name
   { 
   for(int i=0;i<addressBook->contactCount-1;i++)
   {
       for(int j=0;j<addressBook->contactCount-i-1;j++)
       {
       if (strcmp(addressBook->contacts[j].name,addressBook->contacts[j+1].name)>0)
       {
           Contact var=addressBook->contacts[j];
           addressBook->contacts[j]=addressBook->contacts[j+1];
          addressBook->contacts[j+1]=var;// Sort contacts based on the chosen criteria
   }
}
   }
   printf("-------------------------------------------------------------------------\n");
    printf("Index\tName\t\tPhone\t\tEmail\n");
    printf("-------------------------------------------------------------------------\n");
    for(int i=0;i<addressBook->contactCount;i++)
    {
         printf("%d\t",i);
printf("%s\t",addressBook->contacts[i].name);//print name
printf("%s\t",addressBook->contacts[i].phone);//print number
printf("%s\t",addressBook->contacts[i].email);//print email
printf("\n");
    }
     printf("-------------------------------------------------------------------------\n");
   }
   else if(num==2)//if user enter num equals to 2 sort by email
    { 
    for(int i=0;i<addressBook->contactCount-1;i++)
    {
        for(int j=0;j<addressBook->contactCount-i-1;j++)
        {
        if (strcmp(addressBook->contacts[j].email,addressBook->contacts[j+1].email)>0)
        {
            Contact var=addressBook->contacts[j];
            addressBook->contacts[j]=addressBook->contacts[j+1];
           addressBook->contacts[j+1]=var;// Sort contacts based on the chosen criteria
    }
}
    }
    printf("-------------------------------------------------------------------------\n");
    printf("Index\tName\t\tPhone\t\tEmail\n");
    printf("-------------------------------------------------------------------------\n");
    for(int i=0;i<addressBook->contactCount;i++)
    {
         printf("%d\t",i);
printf("%s\t",addressBook->contacts[i].name);//print name
printf("%s\t",addressBook->contacts[i].phone);//print phone number
printf("%s\t",addressBook->contacts[i].email);//print email
printf("\n");
    }
     printf("-------------------------------------------------------------------------\n");
    }
    else //else no need sorting
    {
    printf("-------------------------------------------------------------------------\n");
    printf("Index\tName\t\tPhone\t\tEmail\n");
    printf("-------------------------------------------------------------------------\n");
        for(int i=0;i<addressBook->contactCount;i++)//make list up to contact available
    {
        printf("%d\t",i);
printf("%s\t",addressBook->contacts[i].name); //print name
printf("%s\t",addressBook->contacts[i].phone);//print phone
printf("%s\t",addressBook->contacts[i].email);// print email
printf("\n");
    }
    printf("-------------------------------------------------------------------------\n");
    getchar();//delete the \n
}
}

  void initialize(AddressBook *addressBook) 
  {
    addressBook->contactCount=0;
    loadContactsFromFile(addressBook);
  }

 


void saveAndExit(AddressBook *addressBook) {
    saveContactsToFile(addressBook);
    exit(0);
}

int searchContact(AddressBook *addressBook) 
{
    int option;//declare option to search by choice
    char name[50];//declare name
    char phone[50];//declare phone
    char email[50];//declare email
    printf("\n");
    printf("Enter the option to search\n");//ask the your to enter option
    printf("1.Search by Name:\n2.Search by phone number:\n3.Search by email:");
    printf("\n");
    scanf("%d",&option);//read option to enter
    if(option==1)//if you enter 1 search name
    {
printf("Enter the name to search:");
scanf(" %[^\n]",name);//declare name
        int i,count=0;
        for(i=0;i<addressBook->contactCount;i++)
        {
           if(strcmp(addressBook->contacts[i].name,name)==0)//if name was found print details of that person
           {
            printf("\n");
            printf("%d\t%s\t%s\t%s\n",i,addressBook->contacts[i].name,addressBook->contacts[i].phone,addressBook->contacts[i].email);//print name,number and email
            count++;
           }
        }
            if(count==1)
            {
            return i;//return index which you found details
           }
        if(count>1)
        {
            int j;
            printf("\nwhich index want to search:");
            scanf(" %d",&j);
            printf("\n");
            printf(" %d\t%s\t%s\t%s\n",j,addressBook->contacts[j].name,addressBook->contacts[j].phone,addressBook->contacts[j].email);
            return j;
        }
        if(i==addressBook->contactCount)//if not found the details it was invalid
        {
            printf("contact not found");
            printf("\n");
            return -1;
        }
    }
    else if(option==2)//search by number
    {
  printf("Enter the number to search:");
scanf(" %[^\n]",phone);
        int i;
        for(i=0;i<addressBook->contactCount;i++)
        {
           if(strcmp(addressBook->contacts[i].phone,phone)==0)//if phone number was found print it's details
           {
            printf("\n");
            printf("%d\t%s\t%s\t%s\n",i,addressBook->contacts[i].name,addressBook->contacts[i].phone,addressBook->contacts[i].email);
            return i;
            break;
           }
        }
        if(i==addressBook->contactCount)//if invalid print invalid
        {
            printf("contact not found");
            printf("\n");
            return -1;
        }
    }
    else if(option==3)//search by email
    {
        int i;
printf("Enter the email to serach:");
scanf(" %[^\n]",email);//read email
    for(i=0;i<addressBook->contactCount;i++)
        {
           if(strcmp(addressBook->contacts[i].email,email)==0)//if email was found print details
           {
            printf("\n");
            printf("%d\t%s\t%s\t%s\n",i,addressBook->contacts[i].name,addressBook->contacts[i].phone,addressBook->contacts[i].email);
            return i;
            break;
           }
        }

           if(i==addressBook->contactCount)//invalid print contact not found
        {
            printf("contact not found");
            printf("\n");
            return -1;
        }
        
}
else
{
    printf("Invalid search");
}
}



void createContact(AddressBook *addressBook)
{
    char name[50];//declare name
    char phone[50];//declare phone
    char email[50];//declare email
    printf("\n");
	printf("Enter the name:");
    getchar();
    scanf(" %[^\n]",name);//Read name
    int check1=validname(name);//check name is valid or not
    if(check1==0)//if not valid exit
    {
        printf("Invalid Name\n");
        return;
    }
    else
    {
    printf("Enter the phone:");//if valid enter the phone
    //getchar();
    scanf(" %[^\n]",phone);//read number
    int check2=validphone(phone,addressBook);//check number is valid or not
    if(check2==0)
    {
        printf("Invalid  Number\n");
        return;
    }
    else
    {
    printf("Enter the email:");//if valid check for email
    //getchar();
    scanf(" %[^\n]",email);//read email
    int check3=validemail(email,addressBook);
    if(check3==0)//if all details are valid create contacts
    {
        printf("Invalid Email\n");
        return;
    }
    else{
        strcpy(addressBook->contacts[addressBook->contactCount].name,name);//create name
        strcpy(addressBook->contacts[addressBook->contactCount].phone,phone);//create phone
     strcpy(addressBook->contacts[addressBook->contactCount].email,email);//create email
     printf("Contact Created succesfully\n");
    }
addressBook->contactCount++;//afer that increase count of contacts
    }
    
}
}
    

void editContact(AddressBook *addressBook)
{
    int num,index;
    char name[50];
    char phone[60];
    char email[50];
	int ret=searchContact(addressBook);//search detials which want to edit
    if(ret==-1)//if you not type invalid details
    {
      // ("\nData not found");
        return;
    }
    else
    {
       printf("\nEnter the index to edit:");
       scanf(" %d",&index);//read index
       getchar();
       printf("What to edit:");
       printf("\n1.Name");
        printf("\n2.phone");
        printf("\n3.email");
        printf("\n");
        //getchar();
        scanf(" %d",&num);//read num
        getchar();
    if(num==1)//if user enter 1 means edit name
    {
        scanf("%[^\n]",name);
        int check=validname(name);//enter name must be valid
        if(check==1)//if it is valid
        //getchar();
        {
        strcpy(addressBook->contacts[index].name, name);//edit name
        printf("Name edited successfully");
        printf("\n");
        }
        else{
            printf("Invalid");
            printf("\n");
        }
    }
    else if(num==2)//edit phone number
    {
        scanf("%[^\n]",phone);//read number
       // getchar();
       int check2= validphone(phone,addressBook);//check number is valid or not
       if(check2==1)//valid 
       {
        strcpy(addressBook->contacts[index].phone, phone);//print phone number
        printf("phone number edited succesfully ");
        printf("\n");
       }
       else{
            printf("Invalid");
            printf("\n");
        }
    }
    else if(num==3)
    {
        scanf("%[^\n]",email);
       // getchar();
       int check3= validemail(email,addressBook);//check email
       if(check3==1)//means valid
       {
        strcpy(addressBook->contacts[index].email, email);//edit mail
        printf("Email was edited succesfully");
        printf("\n");
       }
       else{
            printf("Invalid");
            printf("\n");
        }
    }
}
}

void deleteContact(AddressBook *addressBook)
{
    int index;
	int ret=searchContact(addressBook);//first need to search
   if(ret==-1)//search details was not valid print data not found
   {
   // printf("Data not Found\n");
    return;
   }
   printf("\nEnter the index want to delete:");
   scanf(" %d",&index);//read index to get delete
   for(;index<addressBook->contactCount-1;index++)//check till contactcount-1
   {
    addressBook->contacts[index]=addressBook->contacts[index+1];//shfiting array structure
   }
   printf("contact delete successfully");
    addressBook->contactCount--;//decrement contact count
    printf("\n");
}

int validname(char* name)//check name is valid or not
{
    int i=0;
    while(name[i])
    {
    if((name[i]>='a' && name[i]<='z') || (name[i]>='A' && name[i]<='Z') ||(name[i]==' ' ))//any alphabets can type
    {
       i++;
    }
    else
    {
        return 0;
    }
}
if(name[i]=='\0')
{
    return 1;
}
}

int validphone(char* phone,AddressBook *addressBook)//check number is valid or not
{
    if(strlen(phone)==10)//check length of phone number
    {
        int i;
        for(i=0;i<10;i++)
        {
            if(phone[i]>='0' && phone[i]<='9')//it must be digits
            {

            }
            else
            {
                return 0;
            }
        }
        for(i=0;i<addressBook->contactCount;i++)
        {
        if(phone[i]>='0' && phone[i]<='9')
        {
            if(strcmp(phone,addressBook->contacts[i].phone)!=0)//it must be unique
            {

            }
            else
            {
                return 0;
            }
        }
    }
            if(i==addressBook->contactCount)
            {
                return 1;
            }
        }
        else{
            return 0;
        }
    }
    int validemail(char* email,AddressBook *addressBook)
{
    int i;
    for(i=0;i<addressBook->contactCount;i++)//check it is unique or not
    {
        if(strcmp(addressBook->contacts[i].email,email)==0)//if unqiue it is invalid
        {
           return 0;
        }
    }
    if(i==addressBook->contactCount)//if not check it has @ and .
    {
        char* ptr1=(strchr(email,'@'));
        char* ptr2=(strchr(email,'.'));
        if(ptr1==NULL || ptr2==NULL)
        {
            return 0;
        }
        if(ptr1>ptr2)//check  '@' present before '.' if not return 0
        return 0;
        if(ptr1<ptr2)
        {
            int i=0;
            while(email[i])//if valid check till end
            {
                if((email[i]>='0' && email[i]<='9')||(email[i]>='a' && email[i]<='z' )|| (email[i]=='@')||(email[i]=='.'))
                {
                    i++;
                }
                else{
                    return 0;
                }
            }
            return 1;
            
        }
    }
}



