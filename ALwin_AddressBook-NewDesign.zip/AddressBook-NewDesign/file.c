 #include <stdio.h>
 #include "file.h"
 #include "contact.h"

void saveContactsToFile(AddressBook *addressBook) {
FILE* fptr = fopen("file.csv", "w");//check file open correctly or not
    if (fptr == NULL)//if not return null address
     {
        printf("Error opening file for writing!");
        return;
    }

    // Save number of contacts first
    fprintf(fptr,"%d\n",addressBook->contactCount);//first store the content into file

    // Save each contact
    for (int i = 0; i < addressBook->contactCount; i++) {
        fprintf(fptr, "%s,%s,%s\n", 
            addressBook->contacts[i].name,
            addressBook->contacts[i].phone,
            addressBook->contacts[i].email);
    }

    fclose(fptr);
    return;
}

void loadContactsFromFile(AddressBook *addressBook) {
    FILE* fptr=fopen("file.csv","r");//check it is opnened correctely or not
        if(fptr==NULL)
        {
            printf("Failed to open file");//if not return null address
            return;
        }
        fscanf(fptr,"%d\n", &addressBook->contactCount);//read data from file
        for (int i = 0; i< addressBook->contactCount; i++) {
        fscanf(fptr,"\n%[^,],%[^,],%[^\n]",
            addressBook->contacts[i].name,//read name
            addressBook->contacts[i].phone,//read phone
            addressBook->contacts[i].email);//read email
        }
        fclose(fptr);
        return;
    
    
}
